import numpy as np
log = print

def PoissonProcess(rate=5):
    # rate=5 --> 5 requests per second
    interval = np.random.exponential(1 / rate)
    return interval


def request_generator():
    # use process poll
    while True:
        pass


def main():
    log(PoissonProcess())


if __name__ == "__main__":
    main()
    
